from django.contrib import admin
from reserve.models import PreOrder

admin.site.register(PreOrder)
